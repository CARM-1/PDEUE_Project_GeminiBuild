import { A, B } from './data.js';

export const CONTENT_VERSION = '0.3';
export const STORAGE_KEY = 'pdeue-learning-v03';
export const RESET_CONFIRMATION = 'Reset only this companion learning progress? This does not restore an account, change financial state, release governance, or delete PDEUE records.';
export const STALE_KEYS = Object.freeze(['pdeue-learning', 'pdeue-learning-v01', 'pdeue-learning-v02']);
export const MODES = Object.freeze(['guided', 'explore']);
export const PATHWAYS = Object.freeze(['read', 'watch', 'listen', 'explore', 'practice', 'ask']);
export const DEPTHS = Object.freeze(['D1', 'D2', 'D3']);
export const CHAPTERS = Object.freeze(['A', 'B']);
export const LEVELS = Object.freeze([1.5, 1, 0.5]);
export const BLOCKED_FIXTURES = Object.freeze(['BFROZEN', 'BCUSTODIAL', 'BHALT', 'BDRYFAIL', 'BDRYBOUND']);
export const FIXTURE_DEFAULTS = Object.freeze({ BREDUCE: [1.5, 1.5], BRAISE: [1, 1], BFLOOR: [1, 1], BSAME: [1, 1], BHALT: [1.5, null], BDRYFAIL: [null, null], BDRYBOUND: [null, null], BFROZEN: [0, null], BCUSTODIAL: [null, null] });

export function initialState() {
  return {
    version: CONTENT_VERSION, mode: 'guided', chapter: null, depth: 'D1', pathway: 'read',
    guidedIndex: 0, viewed: [], quiz: {}, staticMode: false, muted: false, speed: '1',
    media: 'READY', cue: null, hotspot: null, remember: false,
    practice: { current: 1.5, proposed: 1.5, fixture: 'BREDUCE' }, completion: false
  };
}

export function fixture(chapter, id) {
  const set = chapter === 'A' ? A : chapter === 'B' ? B : null;
  return set && Object.hasOwn(set, id) ? structuredClone(set[id]) : null;
}

export function setMode(state, mode) {
  return MODES.includes(mode) ? { ...state, mode } : state;
}
export function setPathway(state, pathway) {
  return PATHWAYS.includes(pathway) ? { ...state, pathway, media: pathway === 'practice' ? 'PAUSED/FALLBACK' : state.media } : state;
}
export function selectCue(state, cueCount, index) {
  return Number.isInteger(index) && index >= 0 && index < cueCount
    ? { ...state, cue: index, media: 'CUE SELECTED' } : state;
}
export function selectHotspot(state, id, knownIds) {
  return knownIds.includes(id) ? { ...state, hotspot: state.hotspot === id ? null : id, media: 'PAUSED/FALLBACK' } : state;
}
export function selectFixture(state, id) {
  if (!fixture('B', id)) return state;
  const [current, proposed] = FIXTURE_DEFAULTS[id];
  return { ...state, media: 'PAUSED/FALLBACK', practice: { fixture: id, current, proposed } };
}
export function proposeRisk(state, value) {
  const numeric = Number(value);
  if (BLOCKED_FIXTURES.includes(state.practice.fixture) || !LEVELS.includes(numeric)) return state;
  return { ...state, practice: { ...state.practice, proposed: numeric } };
}
export function applyRisk(state) {
  const { fixture: id, current, proposed } = state.practice;
  if (BLOCKED_FIXTURES.includes(id)) return { state, changed: false, message: B[id]?.out || 'Practice mutation unavailable.' };
  if (!LEVELS.includes(proposed)) return { state, changed: false, message: 'Invalid practice value — no change.' };
  if (proposed === current) return { state, changed: false, message: 'No change.' };
  if (proposed > current) return { state, changed: false, message: 'Higher authority required — no practice change.' };
  return { state: { ...state, practice: { ...state.practice, current: proposed } }, changed: true, message: `Accepted practice reduction: ${current.toFixed(2)}% to ${proposed.toFixed(2)}%. Other safeguards remain applicable.` };
}
export function resetPractice(state) {
  const fixtureId = state.practice.fixture;
  const defaults = FIXTURE_DEFAULTS[fixtureId] || FIXTURE_DEFAULTS.BREDUCE;
  return { ...state, media: 'READY', practice: { fixture: fixtureId, current: defaults[0], proposed: defaults[1] } };
}
export function grade(answer, key) {
  return answer === null ? { status: 'empty', message: 'Choose an answer.' } : { status: answer === key ? 'correct' : 'incorrect' };
}
export function markQuiz(state, id, status) { return { ...state, quiz: { ...state.quiz, [id]: status } }; }
export function enterChapter(state, chapter) {
  if (!CHAPTERS.includes(chapter)) return state;
  return { ...state, chapter, completion: false, viewed: [...new Set([...state.viewed, chapter])], pathway: 'read', cue: null, hotspot: null, media: 'READY' };
}
export function continueGuided(state) {
  if (state.mode !== 'guided') return state;
  if (state.chapter === 'A') return enterChapter({ ...state, guidedIndex: 1 }, 'B');
  if (state.chapter === 'B') return { ...state, chapter: null, guidedIndex: 2, completion: true, media: 'READY' };
  return enterChapter({ ...state, guidedIndex: 0 }, 'A');
}
export function parseStored(raw) {
  try {
    const x = JSON.parse(raw);
    if (!x || x.version !== CONTENT_VERSION || !MODES.includes(x.mode) || (x.chapter !== null && !CHAPTERS.includes(x.chapter)) || !DEPTHS.includes(x.depth) || !PATHWAYS.includes(x.pathway)) return { state: initialState(), reset: true };
    const safe = initialState();
    return { state: { ...safe, mode: x.mode, chapter: x.chapter, depth: x.depth, pathway: x.pathway, guidedIndex: [0,1,2].includes(x.guidedIndex) ? x.guidedIndex : 0, viewed: Array.isArray(x.viewed) ? x.viewed.filter(v => CHAPTERS.includes(v)) : [], quiz: x.quiz && typeof x.quiz === 'object' ? x.quiz : {}, staticMode: Boolean(x.staticMode), muted: Boolean(x.muted), speed: ['0.75','1','1.25','1.5','2'].includes(String(x.speed)) ? String(x.speed) : '1', remember: Boolean(x.remember), completion: Boolean(x.completion), media: 'READY', cue: null, hotspot: null }, reset: false };
  } catch { return { state: initialState(), reset: true }; }
}
export function persist(storage, state, rememberStorage) {
  const safe = JSON.stringify({ version: CONTENT_VERSION, mode: state.mode, chapter: state.chapter, depth: state.depth, pathway: state.pathway, guidedIndex: state.guidedIndex, viewed: state.viewed, quiz: state.quiz, staticMode: state.staticMode, muted: state.muted, speed: state.speed, remember: state.remember, completion: state.completion });
  try { storage?.setItem(STORAGE_KEY, safe); } catch {}
  try { if (state.remember) rememberStorage?.setItem(STORAGE_KEY, safe); else rememberStorage?.removeItem(STORAGE_KEY); } catch {}
  return safe;
}

export function purgeLearningKeys(...stores) {
  for (const store of stores) {
    for (const key of [STORAGE_KEY, ...STALE_KEYS]) { try { store?.removeItem(key); } catch {} }
  }
}
export function resetLearning(...stores) { purgeLearningKeys(...stores); return initialState(); }
