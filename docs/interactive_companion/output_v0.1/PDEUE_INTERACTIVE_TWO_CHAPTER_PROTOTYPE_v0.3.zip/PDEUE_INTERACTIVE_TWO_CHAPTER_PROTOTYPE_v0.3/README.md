# PDEUE Interactive Two-Chapter Prototype v0.3

Standalone, deterministic, educational prototype repaired under the WP-6A QB Implementation Terminal Repair Pass v0.3 and controlled by the accepted Interactive Learning Companion design v0.2. It is not an operational PDEUE portal. Examples are fictional; completion grants no financial permission or certification.

## Run

Serve this directory locally (ES modules require HTTP):

```sh
python3 -m http.server 8000 --directory PDEUE_INTERACTIVE_TWO_CHAPTER_PROTOTYPE_v0.3
```

Open `http://127.0.0.1:8000/`. No network access is needed after the local files are present. Run deterministic tests with `npm test` from this directory; they use only Node.js built-ins.

## Implemented repair scope

Terminal repair isolates every Chapter B fixture, presents blocked states as unavailable, purges stale WP-6A storage safely, confirms learning resets, and provides direct untimed cue markers. Guided mode advances Chapter A → Chapter B → the non-certifying completion summary. Explore mode permits direct topic and pathway navigation. All six pathways have explicit selected state. Chapter B has a separate current/proposed downward-only practice state machine. Hotspots, cues, media fallback states, safe progress restoration/version validation, quiz focus handling, and completion metadata are deterministic.

## Boundaries

There is no backend, database, remote dependency, analytics, product endpoint, financial service, AI call, speech-generation call, microphone use, account connection, or arbitrary money input. State defaults to session storage. Local storage is used only when the learner opts into “Remember my learning on this device.” No approved prerecorded audio was supplied; the required fallback statement and approved transcripts remain available, and reload never autoplays.
