# Implementation manifest

* Implementation version: `v0.3`
* Controlling design: Interactive Learning Companion `v0.2` (October 2, 2026)
* Repair authority: PDEUE-DIR-20261002-05 / WP-6A Terminal Repair Pass `v0.3`
* Controlling source ZIP SHA-256: `f8ed511d68545075d025709de035e2b3ed877cf1bd940978ae8c5644757ca5a7`
* Runtime: modern browser supporting ES modules, `structuredClone`, Web Storage, and semantic HTML; local HTTP server recommended.
* Runtime dependencies: none. Deterministic test dependency: Node.js standard library only.
* Network/external dependencies: none.
* Blocked media gates: approved audio, timed captions, measured cue offsets, and synchronization evidence were not supplied.

## Source assets and integrity

`assets/M-03.png`, `assets/M-05.png`, and `assets/M-06.png` are byte-preserved approved source PNGs from the verified controlling package. Approved D1/D2/D3 narration in `js/approved-scripts.js` is unchanged from v0.1. Source asset and implementation file hashes are recorded in `SHA256SUMS.txt`; that hash list excludes itself.
