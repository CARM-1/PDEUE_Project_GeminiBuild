# Accessibility review

Implemented in source: landmarks and headings; skip link; native buttons, radio groups and disclosures; visible focus; no modal keyboard traps; labeled controls; text equivalents; non-color selected labels plus `aria-pressed`; deterministic `aria-expanded` hotspots; polite status and quiz feedback; no-selection focus return; 44 CSS-pixel targets; responsive single-column rules; `prefers-reduced-motion`; user static mode; approved transcripts; captions/status region; and no autoplay.

Automated deterministic state tests and programmatic source checks were performed. Browser rendering and formal assistive-technology validation were unavailable, so formal accessibility certification is **not** claimed. Full keyboard completion, Windows/mobile screen readers, 200% text enlargement, and 400% zoom remain NOT RUN for external QA.
