# Known limitations

* No approved prerecorded narration, WebVTT captions, measured durations, or production cue offsets were supplied. Listen and synchronization gates remain BLOCKED; no substitute audio, speech synthesis, or guessed timing was added.
* Cue selection is a deterministic static/transcript fallback, not an audio synchronization claim.
* Browser and assistive-technology runtime automation was unavailable. Runtime-only keyboard, screen-reader, zoom, responsive, storage-denial, visibility, and network-panel cases remain NOT RUN where appropriate.
* The prototype uses fixed fictional fixtures only. It is not a generalized financial calculator or operational control.
