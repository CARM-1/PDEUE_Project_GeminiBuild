# T01–T26 acceptance results — implementation v0.3

Evidence discipline: PASS is limited to deterministic executable behavior or exact hash/integrity checks. Browser-runtime and assistive-technology behavior was not inferred from source. Audio-dependent gates remain BLOCKED because approved media was not supplied.

| ID | Expected | Actual | Status | Evidence | Limitation |
|---|---|---|---|---|---|
| T01 | Entry/reload/restore/topic changes never autoplay | State and reset initialize READY; runtime lifecycle unexecuted | NOT RUN | deterministic state tests/source | Browser unavailable |
| T02 | A100/A200 exact values and conservation | Accepted fixture truth preserved | PASS | deterministic fixture tests | Fixed fixtures only |
| T03 | ALOSS stays SCMA; no negative split | Accepted loss fixture preserved | PASS | deterministic fixture tests | Fixed fixture only |
| T04 | AZERO/APENDING distinct non-distributable states | Accepted fixture truth preserved | PASS | deterministic fixture tests | Fixed fixtures only |
| T05 | Replay/seek/speed and A200 isolation with correct audio cue | Direct untimed cue fallback works; media sync cannot be evaluated | BLOCKED | cue tests/source | Approved audio/offsets absent |
| T06 | BREDUCE then BRAISE | Isolated defaults; reduction accepted; BRAISE higher proposal rejected at 1.00% | PASS | deterministic state tests | Learning state only |
| T07 | BFLOOR/equal/invalid/double apply | Isolated defaults; lower accepted; equal/invalid/double do not mutate | PASS | deterministic state tests | Learning state only |
| T08 | BHALT never clears or commits | BHALT has no proposal or commit mutation path | PASS | deterministic state tests | UI runtime not run |
| T09 | Dry-powder boundary examples remain isolated | Exact outcomes preserved; both have no risk-mutation path | PASS | deterministic fixture/state tests | Arithmetic examples only |
| T10 | Reset learning state without restoration claim | Confirmation copy tested; reset purges scoped keys and restores safe defaults | PASS | deterministic reset/storage tests | Browser confirmation runtime not run |
| T11 | Keyboard-only completion | Native controls/focus paths present | NOT RUN | source only | Browser unavailable |
| T12 | Screen-reader names/states | Programmatic unavailable/expanded/status text present | NOT RUN | source only | Screen reader unavailable |
| T13 | Reduced motion/static facts equivalent | CSS/static state present | NOT RUN | source only | Visual runtime not run |
| T14 | Missing audio then figure retains fallback | Audio fallback present; figure failure not injected | BLOCKED | source | Approved audio absent; browser fault run unavailable |
| T15 | QA1–QB4 options/feedback/retry/skip | IDs, keys and feedback validated; grading function tested | PASS | deterministic quiz tests | Full browser click matrix not run |
| T16 | 320px and 200% reflow | Responsive rules present | NOT RUN | source only | Browser unavailable |
| T17 | 400% zoom/mobile orientations | Not executed | NOT RUN | none | Browser unavailable |
| T18 | Captions/transcript/cues/mute/speed synchronized | Direct cue markers update deterministic state; synchronization unavailable | BLOCKED | cue tests/source | Approved audio/VTT/timing absent |
| T19 | Storage denial/clear/version safety | Malformed/version mismatch rejected; stale local/session keys purged; reset safe | PASS | deterministic storage tests | Browser denial injection not run |
| T20 | Deterministic replay/FAQ/glossary/quiz; no inference | Deterministic mappings tested; no inference/request API found | PASS | tests/static scan | Browser runtime not run |
| T21 | Network panel shows no external requests | Static scan finds no request APIs/remote assets | NOT RUN | static scan only | Network-panel runtime unavailable |
| T22 | Background/return remains paused | Handler selects PAUSED/FALLBACK; actual audio unavailable | BLOCKED | source | Approved audio absent |
| T23 | Corrupt media/cue or unknown route safe | Invalid cue/fixture rejected; corrupt media unavailable | BLOCKED | deterministic partial tests | Approved media/cue manifest absent |
| T24 | Canonical labels/assets/narration unchanged | Figure and approved-narration hashes match v0.2 baseline | PASS | hash comparison | — |
| T25 | BFROZEN enters 0.00%, cannot mutate/reset/release | Isolated 0.00/null proposal; mutation rejected; BREDUCE re-enters at 1.50% | PASS | deterministic isolation/reset tests | UI pointer/keyboard runtime not run |
| T26 | BCUSTODIAL no self-service; F2-H; reset blocked | Null risk state, no mutation path, accepted authority boundary preserved | PASS | deterministic isolation tests | UI pointer/keyboard runtime not run |
